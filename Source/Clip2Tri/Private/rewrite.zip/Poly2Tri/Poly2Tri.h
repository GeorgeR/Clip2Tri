#pragma once

#include "Poly2Tri/Common/Shapes.h"
#include "Poly2Tri/Sweep/CDT.h"